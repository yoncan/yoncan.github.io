#!/bin/bash
# bash的命令记录
# 主要是为了设置 NAME_OF_KEY 和 SSH_CLIENT_HOST 环境变量

authorized_file="$HOME/.ssh/authorized_keys"
key_finger="/var/log/ssh_key_finger"
tmp_file=$(mktemp -uq /tmp/key.log.XXXXX)


# sshd_log_file 值的设置在脚本末尾有说明
sshd_log_file="/var/log/secure"

RSA_KEY=$(sudo /usr/bin/cat ${sshd_log_file}|awk -v p="$PPID" '/Found matching RSA key/ && $0 ~ p {f=$NF}END{print f}')

# 授权,普通用户可读写
if [ "$UID" == "0" ];then  
    ppid=$PPID
else
    #如果不是root用户，验证指纹的是另外一个进程号
    ppid=`/bin/ps -ef | grep $PPID |grep 'sshd:' |awk '{print $3}'`
fi


# 得到各个key的finger并放在${key_finger}
if [ -f "${authorized_file}" ];then
    while read line
    do
        echo "${line}" >${tmp_file}
        NAME=$(echo "${line}"|awk '{print $3}')
        KEY_FING=$(ssh-keygen -l -f ${tmp_file}|awk '{print $2}')
        grep "$KEY_FING $NAME" ${key_finger} >/dev/null 2>&1 || echo "$KEY_FING $NAME" >>${key_finger}
    done < ${authorized_file}
fi
    

#得到 NAME_OF_KEY 和 SSH_CLIENT_HOST
NAME_OF_KEY='(null)'
if [ -n "$RSA_KEY" -a -f ${key_finger} ];then
    NAME_OF_KEY=$(awk -v key="$RSA_KEY" '$1 == key{print $NF}' ${key_finger})
fi

SSH_CLIENT_HOST=$(echo "$SSH_CLIENT"|awk '{if($1 == "::1" || $1 ~ "localhost"){print "127.0.0.1"}else{print $1}}')

# 参数设置为只读
#readonly NAME_OF_KEY
#readonly SSH_CLIENT_HOST
export NAME_OF_KEY SSH_CLIENT_HOST

[ -f ${tmp_file} ] && /bin/rm ${tmp_file}


# 远程登录执行时
# 请添加到$HOME/.bashrc 或者 /etc/bashrc, "# bash audit"和末尾的 "# end bash audit" 也需要保留
: '
# bash audit
if [ -n "${BASH_EXECUTION_STRING}" ];then
    [ -f "/etc/profile.d/bash-audit.sh" ] && source /etc/profile.d/bash-audit.sh
    if [ -z "${NAME_OF_KEY}" ];then
        NAME_OF_KEY="(null)"
    fi
    logger -t "-bash[${PPID}]" -s "HISTORY: PID=${PPID} PPID=${PPID} User=${USER} USER=${NAME_OF_KEY} HOST=${SSH_CLIENT_HOST} CMD=${BASH_EXECUTION_STRING}" >/dev/null 2>&1
fi
# end bash audit
'

# 在 /etc/ssh/sshd_config 中设置
# 如果SyslogFacility 设置为默认的`AUTHPRIV`, 那就不需要更改
# 请按下面的对应表设置 'sshd_log_file' 变量的值
# AUTHPRIV: /var/log/secure
# AUTH: /var/log/messages
# 如果你设置了其他值, 请对应的修改脚本上的 'sshd_log_file' 变量的值, 同时把对应的权限添加到 /etc/sudoers.d/bash-audit
:<<!
SyslogFacility AUTHPRIV
LogLevel VERBOSE
!
